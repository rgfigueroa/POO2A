/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author roberth
 */
public class ArrayAsArrayList {

    public static void main(String[] args) {
        List<String> miListaP = new ArrayList<String>();

        //  int a[] = {2, 1, 0, 1, 1, 4, 3, 7, 3, 9};
        // int a[] = {1, 1, 0, 0, 3, 2, 9, 9, 5, 0};
        int a[] = {1, 1, 0, 5, 2, 5, 4, 7, 2, 4};

        int n[] = {2, 1, 2, 1, 2, 1, 2, 1, 2};
        int m[] = new int[9];
        int mul = 0;
        int suma = 0;
        int d = 0;
        int decena = 0;
        int res = 0;

        for (int i = 0; i < a.length - 1; i++) {
            mul = a[i] * n[i];
            System.out.println(a[i] + "\t" + n[i] + "=" + mul);
            m[i] = mul;
        }
        for (int i = 0; i < m.length; i++) {
            System.out.println("lo que tiene m es:" + m[i]);
            if (m[i] > 9) {
                m[i] = m[i] - 9;
                suma = suma + m[i];
            } else {
                suma = suma + m[i];
            }
        }
        System.out.println("la suma es:" + suma);
        d = suma % 10;  //1
        System.out.println("d:" + d);
        decena = suma + (10 - d);
        System.out.println("La decena es :" + decena);
        res = decena - suma;
        if (res == 10) {
            res = 0;
        }
        System.out.println("res:" + res);
        if (a[9] == res) {
            System.out.println("la cedula valida");
        } else {
            System.out.println("Invalida");
        }

//        String[] miArray = {"oso", "leon", "tigre", "elefante"};
//        System.out.println("Contenido de palabras: " + miListaP);
//        miListaP = Arrays.asList(miArray);
//        System.out.println("Contenido acutal del ArrayList: " + miListaP);
//
//        List<Integer> miListaEnteros = new ArrayList<Integer>();
//        Integer[] miArrayEnteros = {11, -34, 5, 9};
//        System.out.println("Contenido inicial del ArrayList: " + miListaEnteros);
//        miListaEnteros = Arrays.asList(miArrayEnteros);
//        System.out.println("Contenido acutal del ArrayList: " + miListaEnteros);
//
//        LinkedList<String> miListaStrings = new LinkedList<String>();
//        miListaStrings.add("Liebre");
//        miListaStrings.add("Perro");
//        ArrayList<String> miArrayListStrings = new ArrayList<String>(miListaStrings); //Ejemplo nuevo constructor
//        System.out.println("Contenido del LinkedList " + miListaStrings);
//        System.out.println("Contenido del ArrayList " + miArrayListStrings);
    }

}
