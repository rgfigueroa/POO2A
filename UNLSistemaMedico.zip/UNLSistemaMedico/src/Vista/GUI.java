/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author roberth
 */
public class GUI implements ActionListener {
    
    private int contador = 0;
    private JLabel jlabel;
    
    public GUI() {
        
        JFrame jframe = new JFrame();
        
        JButton jbutton = new JButton("Dar clic");
        jbutton.addActionListener(this);
        
        jlabel = new JLabel("Contador de clic: 0");
        
        JPanel jpanel = new JPanel();
        jpanel.setBorder(BorderFactory.createEmptyBorder(90, 90, 50, 90));
        jpanel.setLayout(new GridLayout(0, 1));
        jpanel.add(jbutton);
        jpanel.add(jlabel);
        
        jframe.add(jpanel, BorderLayout.CENTER);
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setTitle("Nuestra Ventana de GUI");
        jframe.pack();
        jframe.setVisible(true);
        
    }
    
    public static void main(String[] args) {
        System.out.println("Crear una GUI Interfaz Grafica de Usuario");
        new GUI();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        contador = contador + 1;
        jlabel.setText("Contador de clic: " + contador);  
    }
    
}
