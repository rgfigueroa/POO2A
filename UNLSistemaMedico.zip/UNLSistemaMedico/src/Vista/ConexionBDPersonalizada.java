/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista;

import java.awt.Container;
import java.awt.List;
import java.sql.Connection;
import java.sql.ResultSetMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author roberth
 */
public class ConexionBDPersonalizada extends JFrame {

    Connection conexion;
    Statement stInstruccion;
    ResultSet rsResultado;
    int numeroColumnas;

    public ConexionBDPersonalizada() {
        try {

            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("El driver si se ubica correctamente");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/BD2B", "root", "root");
            stInstruccion = conexion.createStatement();
            //consulta de la base de datos
            rsResultado = stInstruccion.executeQuery("select * from producto");

//            while (rsResultado.next()) {
//                System.out.println("Datos: " + rsResultado.getString("nombre"));
//            }
            //Proceso el resultado para presentarlo en la pantalla.
            StringBuffer bufferResultado = new StringBuffer();
            ResultSetMetaData metaDatos = rsResultado.getMetaData();
            numeroColumnas = metaDatos.getColumnCount();
            System.out.println("NUmeroColumna"+numeroColumnas);

            for (int i = 1; i <= numeroColumnas; i++) {
                bufferResultado.append(metaDatos.getColumnName(i) + "\t");
                System.out.println("Columna" + metaDatos.getColumnName(i));
            } 
            bufferResultado.append("\n");
            System.out.println("Se imprime filas");
            while (rsResultado.next()) {
                for (int i = 1; i <= numeroColumnas; i++) {
                    System.out.println("Fila: " + rsResultado.getString(i));
                    bufferResultado.append(rsResultado.getObject(i) + "\t");
                }
                bufferResultado.append("\n");
            }
            System.out.println("Resultado:\n" + bufferResultado.toString());

            JTextArea jtarea = new JTextArea(bufferResultado.toString());
            Container contenedor = getContentPane();
            contenedor.add(new JScrollPane());
            setSize(320, 130);
            setVisible(true);
            stInstruccion.close();
            conexion.close();

        } catch (ClassNotFoundException ex) {
            System.out.println("El driver no se encuntra");
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            System.out.println("No se puede conectar a la BD, revisar el server, user, pass");
            JOptionPane.showMessageDialog(null, "No se puede conectar a la BD, revisar el server, user, pass");
            Logger.getLogger(ConexionBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        System.out.println("A probar");
        ConexionBDPersonalizada cn = new ConexionBDPersonalizada();
        cn.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

}
