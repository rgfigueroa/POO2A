/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 *
 * @author roberth
 */
public class Paciente extends Persona {

    private HistoriaClinica historiaClinica;

    public Paciente(String nombre, Date fechaNacimiento) {
        super(nombre, fechaNacimiento);
        int codigoAleatorioHistoria;
        codigoAleatorioHistoria = (int) (Math.random() * 100);
        System.out.println("Codigo historia generado aleatoriamente:" + codigoAleatorioHistoria);
    }

    @Override
    public int calcularEdadActual(Date fechaNacimiento, Date fechaActual) {
        System.out.println("Calculando la Edad Actual de Paciente Hoy Vierns 12:00");      
        int fechaN = 1900 + fechaNacimiento.getYear();
        int anioActual = 1900 + fechaActual.getYear();
        System.out.println("Anio actual:" + anioActual);
        System.out.println("EDAD ACTUAL PACIENTE: " + (anioActual - fechaN));
        return (anioActual - fechaN);

    }

    /**
     * @return the historiaClinica
     */
    public HistoriaClinica getHistoriaClinica() {
        return historiaClinica;
    }

    /**
     * @param historiaClinica the historiaClinica to set
     */
    public void setHistoriaClinica(HistoriaClinica historiaClinica) {
        this.historiaClinica = historiaClinica;
    }

}
