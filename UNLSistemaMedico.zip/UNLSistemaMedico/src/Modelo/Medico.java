/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.Date;

/**
 *
 * @author roberth
 */
public class Medico extends Empleado implements InterfaceTurno {

    private int matriculaP;

    public Medico(String nombre, Date fechaNacimiento, double sueldo, int matriculaP) {
        super(nombre, fechaNacimiento, sueldo);
        this.matriculaP = matriculaP;
    }

    /**
     * @return the matriculaP
     */
    public int getMatriculaP() {
        return matriculaP;
    }

    /**
     * @param matriculaP the matriculaP to set
     */
    public void setMatriculaP(int matriculaP) {
        this.matriculaP = matriculaP;
    }

    @Override
    public void reservarTurno(int historiClinica) {
        System.out.println("Objeto Medico Reservando un nuevo Turno");

    }

    @Override
    public void eliminarTurno(int historiaClinica) {
        System.out.println("Objeto Medico Eliminando un Turno");
    }

    @Override
    public void visualizarTurno(int historiaClinica) {
        System.out.println("Objeto Medico permitira visualizar un Turno");
    }

//    @Override
//    public void calcularEdadActual() {
//        System.out.println("Calculando la edad actual del MEDICO: " + this.getFechaNacimiento() + " "
//                + this.getNombre() + " " + this.getSueldo());
//    }

}
