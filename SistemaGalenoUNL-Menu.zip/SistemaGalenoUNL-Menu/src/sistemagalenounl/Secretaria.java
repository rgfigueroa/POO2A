/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemagalenounl;

/**
 *
 * @author roberth
 */
public class Secretaria extends Persona implements InterfaceTurno{

    @Override
    public void asignarTurno() {        
        //Logica del rutno
       
       //Agregar la logica para la cita meidica
       // CitaMedica nc= new CitaMedica(listaMedico, paciente, duracion)
        
        
    }
    


}
